﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PizzaAPI.Models;

namespace PizzaAPI.Controllers
{
    //[Route("api/[controller]")]
    //[ApiController]
    //public class PizzaController : ControllerBase
    //{
    //}

    [Route("[controller]")]

    [ApiController]

    public class PizzaController : ControllerBase

    {

        AppDBContext db = null;

        public PizzaController(AppDBContext _db)

        {

            this.db = _db;

        }

        [HttpGet]

        [Route("getstores")]

        public IActionResult GetStore()

        {

            return Ok(db.StoreDetails.ToList());

        }

        //private IActionResult Ok(object value)
        //{
        //    throw new NotImplementedException();
        //}

        [HttpGet]

        [Route("getstore/{id}")]

        public IActionResult GetStoreById(int id)

        {

            var store = db.StoreDetails.Find(id);

            return Ok(store);

        }

        [HttpGet]

        [Route("store/{id}/fooditems")]

        public IActionResult GetStoreFoods(int id)

        {

            var foods = from fo in db.FoodItems

                        where fo.StoreID == id

                        select fo;

            return Ok(foods.ToList());

        }

        [HttpPost]

        [Route("addstore")]

        public IActionResult AddStore([FromBody] StoreDetails s)

        {

            db.StoreDetails.Add(s);

            db.SaveChanges();

            return Ok();

        }

        [HttpPut]

        [Route("editstore/{id}")]

        public IActionResult EditStore(int id, [FromBody] StoreDetails s)

        {

            var store = db.StoreDetails.Find(id);

            if (ModelState.IsValid)

            {

                store.Address = s.Address;

                store.PhoneNumber = s.PhoneNumber;

                db.SaveChanges();

                return Ok();

            }

            return BadRequest();

        }

        [HttpDelete]

        [Route("deletestore/{id}")]

        public IActionResult DeleteStore(int id)

        {

            var store = db.StoreDetails.Find(id);

            db.StoreDetails.Remove(store);

            db.SaveChanges();

            return Ok();

        }

        //food items

        [HttpGet]

        [Route("getfooditems")]

        public IActionResult GetItems()

        {

            return Ok(db.FoodItems.ToList());

        }

        [HttpGet]

        [Route("getfooditem/{id}")]

        public IActionResult GetFoodItemById(int id)

        {

            var food = db.FoodItems.Find(id);

            return Ok(food);

        }

        //[HttpGet]

        //[Route("food/{id}/foodnames")]

        //public IActionResult GetNames(int id)

        //{

        // var names = from f in db.FoodItems

        // where f.FoodID == id

        // select f.FoodName;

        // return Ok(db.FoodItems.ToList());

        //}

        [HttpPost]

        [Route("addfooditems")]

        public IActionResult AddItem([FromBody] FoodItems i)

        {

            db.FoodItems.Add(i);

            db.SaveChanges();

            return Ok();

        }

        [HttpPut]

        [Route("editfooditems/{id}")]

        public IActionResult EditItem(int id, [FromBody] FoodItems i)

        {

            var item = db.FoodItems.Find(id);

            if (ModelState.IsValid)

            {

                item.StoreID = i.StoreID;

                item.FoodName = i.FoodName;

                item.Cost = i.Cost;

                db.SaveChanges();

                return Ok();

            }

            return BadRequest();

        }

        [HttpDelete]

        [Route("deletefooditems/{id}")]

        public IActionResult DeleteItem(int id)

        {

            var item = db.FoodItems.Find(id);

            db.FoodItems.Remove(item);

            db.SaveChanges();

            return Ok();

        }

        //order

        [HttpGet]

        [Route("getorders")]

        public IActionResult GetOrder()

        {

            return Ok(db.Orders.ToList());

        }

        [HttpGet]

        [Route("getorder/{id}")]

        public IActionResult GetOrderById(int id)

        {

            var order = db.Orders.Find(id);

            return Ok(order);

        }

        [HttpPost]

        [Route("addorder")]

        public IActionResult AddOrder([FromBody] Order o)

        {

            db.Orders.Add(o);

            db.SaveChanges();

            return Ok();

        }

        [HttpPut]

        [Route("editorder/{id}")]

        public IActionResult EditOrder(int id, [FromBody] Order o)

        {

            var order = db.Orders.Find(id);

            if (ModelState.IsValid)

            {

                order.TotalCost = o.TotalCost;

                db.SaveChanges();

                return Ok();

            }

            return BadRequest();

        }

        [HttpDelete]

        [Route("deleteorder/{id}")]

        public IActionResult DeleteOrder(int id)

        {

            var order = db.Orders.Find(id);

            db.Orders.Remove(order);

            db.SaveChanges();

            return Ok();

        }

        //orderdetals

        [HttpGet]

        [Route("getorderdetails")]

        public IActionResult GetOrderDetails()

        {

            return Ok(db.OrderDetails.ToList());

        }

        [HttpGet]

        [Route("getorderdetails/{id}")]

        public IActionResult GetOrderDetailsById(int id)

        {

            var orderD = db.OrderDetails.Find(id);

            return Ok(orderD);

        }

        [HttpPost]

        [Route("addorderdetails")]

        public IActionResult AddOrderDetails([FromBody] OrderDetails od)

        {

            db.OrderDetails.Add(od);

            db.SaveChanges();

            return Ok();

        }

        [HttpPut]

        [Route("editorderdetails/{id}")]

        public IActionResult EditOrderDetails(int id, [FromBody] OrderDetails od)

        {

            var orderD = db.OrderDetails.Find(id);

            if (ModelState.IsValid)

            {

                orderD.StoreID = od.StoreID;

                orderD.FoodID = od.FoodID;

                orderD.Quantity = od.Quantity;

                db.SaveChanges();

                return Ok();

            }

            return BadRequest();

        }

        [HttpDelete]

        [Route("deleteorderdetails/{id}")]

        public IActionResult DeleteOrderDetails(int id)

        {

            var orderD = db.OrderDetails.Find(id);

            db.OrderDetails.Remove(orderD);

            db.SaveChanges();

            return Ok();

        }

    }
}
