﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PizzaAPI.Models;

namespace PizzaAPI.Controllers
{
    //[Route("api/[controller]")]
    //[ApiController]
    //public class LoginController : ControllerBase
    //{
    //}

    [Route("[controller]")]

    [ApiController]

    public class LoginController : ControllerBase

    {

        AppDBContext db = null;

        public LoginController(AppDBContext _db)

        {

            this.db = _db;

        }

        [HttpGet]
        [Route("GetUsers")]
        public IActionResult GetUsers()
        {
            return Ok(db.Users.ToList());
        }

        [HttpPost]

        [Route("register")]

        public IActionResult Register([FromBody] RegisterViewModel register)

        {

            if (register == null)

            {

                return BadRequest();

            }

            if (ModelState.IsValid)

            {

                User u = new User();

                u.FirstName = register.FirstName;

                u.LastName = register.LastName;

                u.EmailID = register.EmailID;

                u.PhoneNumber = register.PhoneNumber;

                u.Password = register.Password;

                u.RoleId = register.RoleId;

                db.Users.Add(u);

                db.SaveChanges();

                return Ok();

            }

            return BadRequest("Invalid Registration");

        }

        [HttpPost]

        [Route("loginuser/admin")]

        public IActionResult login(string utype, [FromQuery] LoginViewModel l)

        {

            if (l == null)

            {

                return BadRequest("is null");

            }

            if (utype == "Admin")

            {

                var admin = (from u in db.Users

                             where u.EmailID == "admin@wipro.com" && u.Password == "abcd"

                             select u).SingleOrDefault();

                if (admin != null)

                {

                    return Ok("Welcome, "+admin.FirstName);

                }

                else

                {

                    return BadRequest("admin is null");

                }

            }

            return BadRequest("total");

        }

        [HttpPost]

        [Route("loginuser/user")]

        public IActionResult login([FromBody] LoginViewModel l)

        {

            if (l == null)

            {

                return BadRequest();

            }

            var user = (from u in db.Users

                        where u.EmailID == l.EmailID && u.Password == l.Password

                        select u).SingleOrDefault();

            //LoginViewModel l=new LoginViewModel();

            if (user == null)

            {

                return BadRequest();

            }

            else

            {

               // l.EmailID = user.EmailID;

               // l.Password = user.Password;

               //// db.logins.Add(l);

               // db.SaveChanges();

                return Ok("welcome, "+user.FirstName);

            }

        }

    }
}
