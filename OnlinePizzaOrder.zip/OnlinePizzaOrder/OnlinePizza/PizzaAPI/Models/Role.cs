﻿namespace PizzaAPI.Models
{
    public class Role
    {
        public int RoleId { get; set; }
        public string RoleType { get; set; }
    }
}
