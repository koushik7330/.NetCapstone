﻿using System.ComponentModel.DataAnnotations;

namespace PizzaAPI.Models
{
    public class StoreDetails
    {
        [Key]
        public int StoreID { get; set; }

        public string Address { get; set; }

        public long PhoneNumber { get; set; }

        public virtual List<FoodItems>? FoodItems { get; set; }

        public virtual List<OrderDetails>? OrderDetails { get; set; }
    }
}
