﻿using System.ComponentModel.DataAnnotations;

namespace PizzaAPI.Models
{
    public class Order
    {
        [Key]

        public int OrderID { get; set; }

        public int TotalCost { get; set; }

        public virtual List<OrderDetails>? OrderDetails { get; set; }
    }
}
