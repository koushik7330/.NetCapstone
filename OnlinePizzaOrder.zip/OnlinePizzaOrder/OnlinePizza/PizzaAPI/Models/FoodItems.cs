﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PizzaAPI.Models
{
    public class FoodItems
    {
        [Key]
        public int FoodID { get; set; }

        public string FoodName { get; set; }

        public int Cost { get; set; }

        [ForeignKey("StoreDetails")]
        public int? StoreID { get; set; }

        public virtual StoreDetails? StoreDetails { get; set; }
    }
}
