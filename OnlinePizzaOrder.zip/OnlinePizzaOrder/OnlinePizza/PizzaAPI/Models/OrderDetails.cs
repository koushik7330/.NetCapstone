﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations.Schema;

namespace PizzaAPI.Models
{
    public class OrderDetails
    {
        public int OrderDetailsID { get; set; }
        [ForeignKey("Order")]
        public int? OrderID { get; set; }
        [ForeignKey("StoreDetails")]
        public int? StoreID { get; set; }

        [ForeignKey("FoodItems")]
        public int? FoodID { get; set; }

        public int Quantity { get; set; }

        public virtual Order? Order { get; set; }

        public virtual StoreDetails? StoreDetails { get; set; }

        public virtual FoodItems? FoodItems { get; set; }
    }
}
