﻿using System.ComponentModel.DataAnnotations;

namespace PizzaAPI.Models
{
    public class RegisterViewModel
    {
        public string EmailID { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public long PhoneNumber { get; set; }

        public string Password { get; set; }

        [Compare("Password", ErrorMessage = "Password doesnot match")]

        public string ConfirmPassword { get; set; }

        public int RoleId{ get; set; }
    }
}
