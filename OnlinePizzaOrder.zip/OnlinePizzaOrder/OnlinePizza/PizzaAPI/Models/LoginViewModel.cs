﻿namespace PizzaAPI.Models
{
    public class LoginViewModel
    {
      //  public int LoginID { get; set; }

        public string EmailID { get; set; }

        //public string UserType { get; set; }

        public string Password { get; set; }
    }
}
