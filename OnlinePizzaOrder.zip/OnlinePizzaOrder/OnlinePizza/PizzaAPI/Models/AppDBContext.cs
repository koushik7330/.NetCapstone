﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace PizzaAPI.Models
{
    public class AppDBContext:DbContext
    {
        public AppDBContext(DbContextOptions<AppDBContext> options) : base(options)
        {
        }

        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<User> Role { get; set; }
        public virtual DbSet<FoodItems> FoodItems { get; set; } = null!;

        public virtual DbSet<OrderDetails> OrderDetails { get; set; } = null!;

        public virtual DbSet<StoreDetails> StoreDetails { get; set; } = null!;

        public virtual DbSet<Order> Orders { get; set; } = null!;

        //  public virtual DbSet<LoginViewModel> logins { get; set; }

    }

}
